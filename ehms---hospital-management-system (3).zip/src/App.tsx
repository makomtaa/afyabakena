/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useCallback, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { Dashboard } from './components/Dashboard';
import { Reception } from './components/Reception';
import { Department } from './components/Department';
import { EditModal, TransferModal } from './components/Modals';
import { Patient, DepartmentId, DEPARTMENTS } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [view, setView] = useState<DepartmentId>('dashboard');
  const [patients, setPatients] = useState<Patient[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal states
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [transferringId, setTransferringId] = useState<string | null>(null);
  const [toast, setToast] = useState<{message: string, type: 'info' | 'success'} | null>(null);

  const showToast = (message: string, type: 'info' | 'success' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const addPatient = useCallback((patientData: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => {
    const now = new Date().toISOString();
    const newPatient: Patient = {
      ...patientData,
      id: Math.random().toString(36).substring(7),
      status: 'pending',
      createdAt: now,
      updatedAt: now
    } as any;
    
    setPatients(prev => [newPatient, ...prev]);
    showToast(`Patient registered and sent to ${DEPARTMENTS.find(d => d.id === patientData.department)?.label}`);
  }, []);

  const updatePatient = useCallback((updated: Patient) => {
    setPatients(prev => prev.map(p => p.id === updated.id ? { ...updated, updatedAt: new Date().toISOString() } : p));
    setEditingPatient(null);
    showToast('Patient record updated', 'success');
  }, []);

  const transferPatient = useCallback((id: string, newDept: DepartmentId) => {
    setPatients(prev => prev.map(p => p.id === id ? { ...p, department: newDept, status: 'pending', updatedAt: new Date().toISOString() } : p));
    setTransferringId(null);
    showToast(`Patient transferred to ${DEPARTMENTS.find(d => d.id === newDept)?.label}`, 'success');
  }, []);

  const radTransmit = useCallback((id: string, notes: string, doctor: string) => {
    setPatients(prev => prev.map(p => p.id === id ? { 
      ...p, 
      radiologyNotes: notes, 
      assignedTo: doctor, 
      status: 'in-progress',
      updatedAt: new Date().toISOString() 
    } : p));
    showToast(`Imaging reports transmitted to ${doctor}`);
  }, []);

  const filteredPatients = useMemo(() => {
    return patients.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.patientId.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [patients, searchQuery]);

  const urgentCount = useMemo(() => 
    patients.filter(p => p.priority === 'high' && p.status === 'pending').length
  , [patients]);

  const currentViewTitle = useMemo(() => {
    if (view === 'dashboard') return 'Hospital Dashboard';
    if (view === 'reception') return 'Reception Portal';
    return DEPARTMENTS.find(d => d.id === view)?.label || 'Clinic';
  }, [view]);

  return (
    <div className="h-screen flex overflow-hidden bg-slate-50 font-sans">
      <Sidebar currentView={view} setView={setView} />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          currentTitle={currentViewTitle}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          urgentCount={urgentCount}
        />

        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {view === 'dashboard' && <Dashboard patients={filteredPatients} />}
              {view === 'reception' && (
                <Reception 
                  patients={filteredPatients} 
                  addPatient={addPatient} 
                  onTransfer={setTransferringId}
                />
              )}
              {DEPARTMENTS.map(dept => dept.id === view ? (
                <Department 
                  key={dept.id}
                  deptId={dept.id}
                  patients={filteredPatients}
                  onEdit={setEditingPatient}
                  onTransfer={setTransferringId}
                  onRadTransmit={radTransmit}
                />
              ) : null)}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Footer Status Bar */}
      <footer className="h-8 bg-blue-600 text-white px-4 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest shrink-0">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
            System Live: {new Date().toLocaleTimeString()}
          </div>
          <div className="opacity-70">Region: Europe-West1</div>
        </div>
        <div className="flex gap-6">
          <span className="opacity-70 font-medium">Patients Synced: {patients.length}</span>
          <span className="opacity-70 font-medium">Session: Admin-0425</span>
          <span className="bg-white/20 px-2 py-0.5 rounded">eHMS / Enterprise</span>
        </div>
      </footer>

      {/* Global Modals */}
      <EditModal 
        isOpen={!!editingPatient} 
        onClose={() => setEditingPatient(null)} 
        patient={editingPatient}
        onSave={updatePatient}
      />
      <TransferModal 
        isOpen={!!transferringId}
        onClose={() => setTransferringId(null)}
        patientId={transferringId}
        onConfirm={transferPatient}
      />

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 px-6 py-3 rounded-xl shadow-2xl z-50 text-white font-medium flex items-center gap-3 ${
              toast.type === 'success' ? 'bg-emerald-600' : 'bg-slate-800'
            }`}
          >
            {toast.message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
