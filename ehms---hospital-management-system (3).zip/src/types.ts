export type DepartmentId = 'dashboard' | 'reception' | 'laboratory' | 'radiology' | 'pharmacy' | 'medical' | 'dental' | 'nursing';

export type Status = 'pending' | 'in-progress' | 'completed';
export type Priority = 'low' | 'medium' | 'high';

export interface Patient {
  id: string;
  patientId: string;
  name: string;
  age: number;
  gender: string;
  contact: string;
  department: DepartmentId;
  priority: Priority;
  notes: string;
  status: Status;
  createdAt: string;
  updatedAt: string;
  assignedTo?: string;
  diagnosis?: string;
  prescription?: string;
  labResults?: string;
  radiologyNotes?: string;
}

export interface DeptConfig {
  id: DepartmentId;
  label: string;
  color: string;
  lightColor: string;
  textColor: string;
}

export const DEPARTMENTS: DeptConfig[] = [
  { id: 'laboratory', label: 'Laboratory', color: 'purple', lightColor: 'bg-purple-100', textColor: 'text-purple-600' },
  { id: 'radiology', label: 'Radiology', color: 'cyan', lightColor: 'bg-cyan-100', textColor: 'text-cyan-600' },
  { id: 'pharmacy', label: 'Pharmacy', color: 'green', lightColor: 'bg-green-100', textColor: 'text-green-600' },
  { id: 'medical', label: 'Medical Doctors', color: 'red', lightColor: 'bg-red-100', textColor: 'text-red-600' },
  { id: 'dental', label: 'Dental', color: 'indigo', lightColor: 'bg-indigo-100', textColor: 'text-indigo-600' },
  { id: 'nursing', label: 'Nursing', color: 'pink', lightColor: 'bg-pink-100', textColor: 'text-pink-600' },
];
