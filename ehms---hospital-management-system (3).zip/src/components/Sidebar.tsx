import { 
  LayoutDashboard, 
  UserPlus, 
  Beaker, 
  Scan, 
  Pill, 
  Stethoscope, 
  Activity, 
  HeartPulse,
  Hospital
} from 'lucide-react';
import { DepartmentId, DEPARTMENTS } from '../types';
import { motion } from 'motion/react';

interface SidebarProps {
  currentView: DepartmentId;
  setView: (view: DepartmentId) => void;
}

export function Sidebar({ currentView, setView }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'reception', label: 'Reception', icon: UserPlus },
  ];

  const deptItems = [
    { id: 'laboratory', label: 'Laboratory', icon: Beaker },
    { id: 'radiology', label: 'Radiology', icon: Scan },
    { id: 'pharmacy', label: 'Pharmacy', icon: Pill },
    { id: 'medical', label: 'Medical Doctors', icon: Stethoscope },
    { id: 'dental', label: 'Dental', icon: Activity },
    { id: 'nursing', label: 'Nursing', icon: HeartPulse },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0">
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
            <Hospital className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-slate-800 leading-none">City Hospital</h1>
            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mt-1">eHMS System v2.0</p>
          </div>
        </div>
      </div>

      <div className="px-6 py-3 border-b border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-2 text-xs">
          <span className="pulse-dot w-2 h-2 bg-green-500 rounded-full"></span>
          <span className="text-slate-500 font-medium">Network: 122.333.44.5</span>
        </div>
      </div>

      <nav className="flex-1 py-4 overflow-y-auto px-2 space-y-1">
        <div className="px-4 mb-2 text-[10px] uppercase font-bold text-slate-400 tracking-widest">
          Main Menu
        </div>
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as DepartmentId)}
            className={`w-full flex items-center gap-3 px-3 py-2 text-left rounded-md transition-all text-sm font-medium ${
              currentView === item.id 
                ? 'bg-blue-50 text-blue-700' 
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <item.icon className={`w-4 h-4 ${currentView === item.id ? 'text-blue-600' : 'text-slate-400'}`} />
            <span>{item.label}</span>
          </button>
        ))}

        <div className="px-4 mt-6 mb-2 text-[10px] uppercase font-bold text-slate-400 tracking-widest">
          Departments
        </div>
        {deptItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as DepartmentId)}
            className={`w-full flex items-center gap-3 px-3 py-2 text-left rounded-md transition-all text-sm font-medium ${
              currentView === item.id 
                ? 'bg-blue-50 text-blue-700' 
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <item.icon className={`w-4 h-4 ${currentView === item.id ? 'text-blue-600' : 'text-slate-400'}`} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg">
          <div className="w-8 h-8 bg-slate-900 rounded-md flex items-center justify-center font-bold text-xs text-white">
            AD
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-slate-800 truncate">Admin User</p>
            <p className="text-[10px] text-slate-500 font-medium truncate uppercase tracking-tighter">System Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
