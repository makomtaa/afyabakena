import { Search, Bell } from 'lucide-react';
import { DepartmentId } from '../types';

interface TopBarProps {
  currentTitle: string;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  urgentCount: number;
}

export function TopBar({ currentTitle, searchQuery, setSearchQuery, urgentCount }: TopBarProps) {
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric'
  });

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shadow-sm shrink-0">
      <div>
        <h2 className="text-lg font-bold tracking-tight text-slate-800">{currentTitle}</h2>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider leading-none mt-0.5">{currentDate}</p>
      </div>

      <div className="flex items-center gap-6">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search database..." 
            className="pl-9 pr-4 py-1.5 w-64 bg-slate-50 border border-slate-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        </div>

        <button className="relative p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-all">
          <Bell className="w-5 h-5" />
          {urgentCount > 0 && (
            <span className="absolute top-1 right-1 px-1 min-w-[16px] h-4 bg-red-600 border-2 border-white text-white text-[8px] rounded-full flex items-center justify-center font-bold">
              {urgentCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
