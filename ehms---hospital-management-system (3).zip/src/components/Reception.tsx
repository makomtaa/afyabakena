import { useState } from 'react';
import { Patient, DepartmentId, DEPARTMENTS, Priority } from '../types';
import { motion } from 'motion/react';
import { ArrowRightLeft, UserPlus } from 'lucide-react';

interface ReceptionProps {
  patients: Patient[];
  addPatient: (patient: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => void;
  onTransfer: (id: string) => void;
}

export function Reception({ patients, addPatient, onTransfer }: ReceptionProps) {
  const [formData, setFormData] = useState({
    patientId: '',
    name: '',
    age: '',
    gender: '',
    contact: '',
    department: '' as DepartmentId,
    priority: 'low' as Priority,
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addPatient({
      ...formData,
      age: parseInt(formData.age),
    } as any);
    setFormData({
      patientId: '',
      name: '',
      age: '',
      gender: '',
      contact: '',
      department: '' as DepartmentId,
      priority: 'low',
      notes: ''
    });
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-sm border border-slate-100 p-6"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-blue-600" />
          Register New Patient
        </h3>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Patient ID</label>
            <input
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="e.g., PAT-001"
              value={formData.patientId}
              onChange={e => setFormData({...formData, patientId: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Full Name</label>
            <input
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Enter name"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Age</label>
            <input
              required
              type="number"
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Age"
              value={formData.age}
              onChange={e => setFormData({...formData, age: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Gender</label>
            <select
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.gender}
              onChange={e => setFormData({...formData, gender: e.target.value})}
            >
              <option value="">Select</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Contact</label>
            <input
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Phone number"
              value={formData.contact}
              onChange={e => setFormData({...formData, contact: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Department</label>
            <select
              required
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.department}
              onChange={e => setFormData({...formData, department: e.target.value as DepartmentId})}
            >
              <option value="">Select Department</option>
              {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.label}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Priority</label>
            <select
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.priority}
              onChange={e => setFormData({...formData, priority: e.target.value as Priority})}
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High - Urgent</option>
            </select>
          </div>
          <div className="lg:col-span-1 flex items-end">
             <button type="submit" className="w-full bg-blue-600 text-white font-semibold py-2 rounded-lg hover:bg-blue-700 transition-colors">
               Register & Send
             </button>
          </div>
          <div className="lg:col-span-4 space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase">Initial Notes</label>
            <textarea
              className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
              rows={2}
              placeholder="Reason for visit, symptoms, etc."
              value={formData.notes}
              onChange={e => setFormData({...formData, notes: e.target.value})}
            />
          </div>
        </form>
      </motion.div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800">Registered Patients</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 text-slate-500 text-xs font-semibold uppercase">
              <tr>
                <th className="px-6 py-4 text-left">Patient</th>
                <th className="px-6 py-4 text-left">Contact</th>
                <th className="px-6 py-4 text-left">Clinic</th>
                <th className="px-6 py-4 text-left">Priority</th>
                <th className="px-6 py-4 text-left">Status</th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {patients.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">No registered patients</td>
                </tr>
              ) : (
                patients.map(p => (
                  <tr key={p.id} className={`hover:bg-slate-50 transition-colors priority-${p.priority}`}>
                    <td className="px-6 py-4">
                      <div className="text-sm font-semibold text-slate-800">{p.name}</div>
                      <div className="text-xs text-slate-500">{p.patientId} • {p.age}y {p.gender}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{p.contact}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 text-xs rounded-full ${DEPARTMENTS.find(d => d.id === p.department)?.lightColor} ${DEPARTMENTS.find(d => d.id === p.department)?.textColor}`}>
                        {DEPARTMENTS.find(d => d.id === p.department)?.label}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                       <span className={`px-2 py-0.5 text-xs rounded-full ${p.priority === 'high' ? 'bg-red-100 text-red-700' : p.priority === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                        {p.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                       <span className={`px-2 py-0.5 text-xs rounded-full status-${p.status}`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button 
                        onClick={() => onTransfer(p.id)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Transfer Patient"
                      >
                        <ArrowRightLeft className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
