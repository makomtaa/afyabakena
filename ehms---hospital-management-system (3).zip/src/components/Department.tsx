import { Patient, DEPARTMENTS, DepartmentId } from '../types';
import { motion } from 'motion/react';
import { Edit2, ArrowRightLeft, Send } from 'lucide-react';
import { useState } from 'react';

interface DepartmentProps {
  deptId: DepartmentId;
  patients: Patient[];
  onEdit: (patient: Patient) => void;
  onTransfer: (id: string) => void;
  onRadTransmit?: (id: string, notes: string, doctor: string) => void;
}

export function Department({ deptId, patients, onEdit, onTransfer, onRadTransmit }: DepartmentProps) {
  const dept = DEPARTMENTS.find(d => d.id === deptId);
  const filteredPatients = patients.filter(p => p.department === deptId);

  // Radiology specific state
  const [radTarget, setRadTarget] = useState('');
  const [radDoctor, setRadDoctor] = useState('Dr. Smith');
  const [radNotes, setRadNotes] = useState('');

  if (!dept) return null;

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 ${dept.lightColor} rounded-xl flex items-center justify-center`}>
            <div className={`w-6 h-6 ${dept.textColor}`}>
               {deptId === 'laboratory' && <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>}
               {deptId === 'radiology' && <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>}
               {deptId === 'pharmacy' && <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>}
            </div>
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800">{dept.label}</h3>
            <p className="text-sm text-slate-500">Manage patient records and clinical workflow</p>
          </div>
        </div>
      </div>

      {/* Radiology Imaging System */}
      {deptId === 'radiology' && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-linear-to-r from-cyan-50 to-blue-50 rounded-xl p-6 border border-cyan-100 shadow-sm"
        >
          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Send className="w-5 h-5 text-cyan-600" />
            Radiographer Imaging Transfer
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Patient</label>
              <select 
                className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-cyan-500"
                value={radTarget}
                onChange={e => setRadTarget(e.target.value)}
              >
                <option value="">Select Patient</option>
                {filteredPatients.map(p => <option key={p.id} value={p.id}>{p.name} ({p.patientId})</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Send To</label>
              <select 
                className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-cyan-500"
                value={radDoctor}
                onChange={e => setRadDoctor(e.target.value)}
              >
                <option value="Dr. Smith">Dr. Smith</option>
                <option value="Dr. Johnson">Dr. Johnson</option>
                <option value="Dr. Williams">Dr. Williams</option>
                <option value="Dr. Brown">Dr. Brown</option>
              </select>
            </div>
            <div className="flex items-end">
              <button 
                onClick={() => onRadTransmit?.(radTarget, radNotes, radDoctor)}
                className="w-full bg-cyan-600 text-white font-semibold py-2 rounded-lg hover:bg-cyan-700 transition-colors"
                disabled={!radTarget}
              >
                Send to Doctor
              </button>
            </div>
            <div className="md:col-span-3 space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Imaging Notes</label>
              <input 
                className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-cyan-500"
                placeholder="Findings or procedure notes..."
                value={radNotes}
                onChange={e => setRadNotes(e.target.value)}
              />
            </div>
          </div>
        </motion.div>
      )}

      {/* Patients Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className={`${dept.lightColor} ${dept.textColor} text-xs font-bold uppercase`}>
              <tr>
                <th className="px-6 py-4 text-left">Patient</th>
                <th className="px-6 py-4 text-left">Priority</th>
                {deptId === 'laboratory' && <th className="px-6 py-4 text-left">Lab Results</th>}
                {deptId === 'pharmacy' && <th className="px-6 py-4 text-left">Prescription</th>}
                {deptId === 'radiology' && <th className="px-6 py-4 text-left">Images</th>}
                {(deptId === 'medical' || deptId === 'dental') && <th className="px-6 py-4 text-left">Diagnosis</th>}
                <th className="px-6 py-4 text-left">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPatients.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">No patients in queue</td>
                </tr>
              ) : (
                filteredPatients.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="text-sm font-semibold text-slate-800">{p.name}</div>
                      <div className="text-xs text-slate-500">{p.patientId} • {p.age}y {p.gender}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 text-xs rounded-full ${p.priority === 'high' ? 'bg-red-100 text-red-700' : p.priority === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                        {p.priority}
                      </span>
                    </td>
                    {deptId === 'laboratory' && <td className="px-6 py-4 text-sm text-slate-600 max-w-xs truncate">{p.labResults || '-'}</td>}
                    {deptId === 'pharmacy' && <td className="px-6 py-4 text-sm text-slate-600 max-w-xs truncate">{p.prescription || '-'}</td>}
                    {deptId === 'radiology' && <td className="px-6 py-4 text-sm text-slate-600">{p.radiologyNotes || '-'}</td>}
                    {(deptId === 'medical' || deptId === 'dental') && <td className="px-6 py-4 text-sm text-slate-600 max-w-xs truncate">{p.diagnosis || '-'}</td>}
                    <td className="px-6 py-4">
                       <span className={`px-2 py-0.5 text-xs rounded-full status-${p.status}`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => onEdit(p)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => onTransfer(p.id)}
                          className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        >
                          <ArrowRightLeft className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
