import { useState, useEffect } from 'react';
import { Patient, Status, DepartmentId, DEPARTMENTS } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check } from 'lucide-react';

interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient | null;
  onSave: (updated: Patient) => void;
}

export function EditModal({ isOpen, onClose, patient, onSave }: EditModalProps) {
  const [data, setData] = useState<Partial<Patient>>({});

  useEffect(() => {
    if (patient) setData({ ...patient });
  }, [patient]);

  if (!isOpen || !patient) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="text-lg font-bold text-slate-800">Update Clinical Record</h3>
            <p className="text-xs text-slate-500">{patient.name} ({patient.patientId})</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Status</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
              value={data.status}
              onChange={e => setData({...data, status: e.target.value as Status})}
            >
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Clinical Notes</label>
            <textarea 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={3}
              value={data.notes}
              onChange={e => setData({...data, notes: e.target.value})}
            />
          </div>

          {['medical', 'dental'].includes(patient.department) && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Diagnosis</label>
              <textarea 
                className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={2}
                value={data.diagnosis}
                onChange={e => setData({...data, diagnosis: e.target.value})}
              />
            </div>
          )}

          {['pharmacy', 'medical'].includes(patient.department) && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Prescription</label>
              <textarea 
                className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={2}
                value={data.prescription}
                onChange={e => setData({...data, prescription: e.target.value})}
              />
            </div>
          )}

          {patient.department === 'laboratory' && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Lab Results</label>
              <textarea 
                className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={2}
                value={data.labResults}
                onChange={e => setData({...data, labResults: e.target.value})}
              />
            </div>
          )}
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex gap-3">
          <button 
            onClick={onClose}
            className="flex-1 px-4 py-2 font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={() => onSave(data as Patient)}
            className="flex-1 px-4 py-2 font-semibold bg-blue-600 text-white hover:bg-blue-700 rounded-lg shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" />
            Save Changes
          </button>
        </div>
      </motion.div>
    </div>
  );
}

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string | null;
  onConfirm: (id: string, dept: DepartmentId) => void;
}

export function TransferModal({ isOpen, onClose, patientId, onConfirm }: TransferModalProps) {
  const [targetDept, setTargetDept] = useState<DepartmentId | ''>('');

  if (!isOpen || !patientId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">Transfer Patient</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Destination Department</label>
            <select 
              className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
              value={targetDept}
              onChange={e => setTargetDept(e.target.value as DepartmentId)}
            >
              <option value="">Select Department</option>
              {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.label}</option>)}
            </select>
          </div>
        </div>

        <div className="p-6 bg-slate-50 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2 font-semibold text-slate-600 hover:bg-slate-200 rounded-lg">
            Cancel
          </button>
          <button 
            disabled={!targetDept}
            onClick={() => onConfirm(patientId, targetDept as DepartmentId)}
            className="flex-1 py-2 font-semibold bg-emerald-600 text-white hover:bg-emerald-700 rounded-lg shadow-md disabled:opacity-50"
          >
            Confirm
          </button>
        </div>
      </motion.div>
    </div>
  );
}
