import { Users, Clock, Loader2, CheckCircle2 } from 'lucide-react';
import { Patient, DEPARTMENTS } from '../types';
import { motion } from 'motion/react';

interface DashboardProps {
  patients: Patient[];
}

export function Dashboard({ patients }: DashboardProps) {
  const stats = [
    { label: 'Total Patients', value: patients.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Pending', value: patients.filter(p => p.status === 'pending').length, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-100' },
    { label: 'In Progress', value: patients.filter(p => p.status === 'in-progress').length, icon: Loader2, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Completed', value: patients.filter(p => p.status === 'completed').length, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-100' },
  ];

  const deptActivity = DEPARTMENTS.map(dept => {
    const count = patients.filter(p => p.department === dept.id).length;
    return { ...dept, count };
  });

  const maxCount = Math.max(...deptActivity.map(d => d.count), 1);
  const recentActivity = patients.slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="p-5 bg-white border border-slate-200 rounded-lg shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                <p className={`text-2xl font-bold tracking-tight text-slate-800`}>{stat.value}</p>
              </div>
              <div className={`w-10 h-10 ${stat.bg.replace('bg-', 'bg-').replace('100', '50')} rounded-lg border ${stat.bg.replace('bg-', 'border-').replace('100', '100')} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
            <div className="mt-2 text-[10px] font-bold text-slate-400 flex items-center gap-1">
              <span className="text-emerald-600">LIVE</span> update sync
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dept Activity */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-6 flex items-center gap-2">
            <span className="w-1 h-4 bg-blue-600 rounded-full"></span>
            Department Throughput
          </h3>
          <div className="space-y-4">
            {deptActivity.map((dept) => (
              <div key={dept.id} className="flex items-center gap-4">
                <span className="w-32 text-xs text-slate-500 font-bold uppercase tracking-tighter truncate">{dept.label}</span>
                <div className="flex-1 bg-slate-100 rounded-md h-2 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(dept.count / maxCount) * 100}%` }}
                    className={`h-full rounded-full ${dept.textColor.replace('text-', 'bg-')}`}
                  />
                </div>
                <span className="w-8 text-xs font-bold text-slate-700 text-right">{dept.count}</span>
              </div>
            ))}
          </div>
          <div className="mt-8 pt-4 border-t border-slate-100 text-center text-[10px] text-slate-400 font-medium">
            Bi-weekly Performance Comparison breakdown available in logs
          </div>
        </div>

        {/* Recent Patients */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50/50 border-b border-slate-200 flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Queue Active Status</h3>
            <span className="px-2 py-0.5 bg-green-100 text-green-700 text-[10px] font-bold rounded-full">LIVE</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">Identifier</th>
                  <th className="px-6 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">Clinic</th>
                  <th className="px-6 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentActivity.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-slate-400 text-sm">Empty registry</td>
                  </tr>
                ) : (
                  recentActivity.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-sm font-bold text-slate-800">{p.name}</div>
                        <div className="text-[10px] font-bold text-slate-400">{p.patientId}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-0.5 text-[10px] font-bold rounded uppercase ${DEPARTMENTS.find(d => d.id === p.department)?.lightColor} ${DEPARTMENTS.find(d => d.id === p.department)?.textColor}`}>
                          {DEPARTMENTS.find(d => d.id === p.department)?.label}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-[10px] rounded status-${p.status}`}>
                          {p.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
